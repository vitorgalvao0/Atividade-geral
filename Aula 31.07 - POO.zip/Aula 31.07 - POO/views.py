def menu_principal():
    print( "1 - Criar humano\n2 - Informações do humano\n3 - Criar cachorro\n4 - Informações do cachorro\n5 - Sair")


def separar():
    print("------------------")

