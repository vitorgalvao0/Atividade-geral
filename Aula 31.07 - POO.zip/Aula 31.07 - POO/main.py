from classe import *
from views import *

dados_humano = []
dados_cao = []



def criar_cao():
    nome = input("Diga o nome do seu cao: ")
    coracao = input("Seu cachorro tem coracao: ")
    cor = input("Qual a cor do seu cao: ")
    peso = float(input("Digite o peso do seu cao: "))
    sexo =  input("Qual o sexo do seu cao: ")
    idade = input("Quantos anos seu cao tem: ")
    tamanho = int(input("Qual o tamanho do seu cao: "))
    raca = input("Qual a raca do seu cao: ")
    cao = Cachorro(nome,coracao,cor,peso,sexo,idade,tamanho,raca)
    dados_cao.append(cao)
    return cao


def criar_humano():
    nome = input("Qual o nome da pessoa: ")
    coracao = input("Essa pessoa tem coracao: ")
    cor = input("Qual a cor dessa pessoa : ")
    sexo =  input("Qual o sexo da pessoa: ")
    idade = input("Qual a idade da pessoa: ")
    peso = float(input("Qual o peso dessa pessoa: "))
    salario = int(input("Qual o salario dessa pessoa: "))
    cpf = int(input("Qual o CPF dessa pessoa: "))
    pessoa = Humano( nome, coracao, cor, sexo,idade, peso, salario, cpf)
    dados_humano.append(pessoa)
    return pessoa

def ver_info_humano():
    for pessoa in dados_humano:
        print ("Nome: ",pessoa.nome)
        print ("Coracao: ",pessoa.coracao)
        print ("Cor: ",pessoa.cor)
        print ("Peso: ",pessoa.peso)
        print ("Sexo: ",pessoa.sexo)
        print ("idade: ",pessoa.idade)
        print ("Peso: ",pessoa.peso)
        print ("Salario",pessoa.salario)
        print ("Cpf",pessoa.cpf)

def ver_info_cao():
   for cao in dados_cao:
        print ("Nome: ",cao.nome)
        print ("Coracao: ",cao.coracao)
        print ("Cor: ",cao.cor)
        print ("Peso: ",cao.peso)
        print ("Sexo: ",cao.sexo)
        print ("idade: ",cao.idade)
        print ("Tamanho: ",cao.tamanho)
        print ("Raça",cao.raca)

while True:
    separar()
    menu_principal()
    separar()
   
    op = int(input("Qual a funcao desejada: "))

    if 1 == op:
        criar_humano()

    if op == 2: 
        ver_info_humano()

    if op == 3:
        criar_cao()

    if op == 4: 
        ver_info_cao()

    if op == 5:
        break

